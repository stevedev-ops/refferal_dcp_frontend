import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { toast } from "sonner";
import { Share2, Copy, CheckCircle2, ExternalLink, Users, Phone, MessageCircle } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";

interface Props {
  memberId: string;
}

interface MemberStats {
  name: string;
  referral_code: string;
  invitees: {
    name: string;
    orpp_registered: boolean;
    created_at: string;
  }[];
}

export default function Dashboard({ memberId }: Props) {
  const [stats, setStats] = useState<MemberStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, [memberId]);

  const fetchStats = async () => {
    try {
      const response = await fetch(`/api/member/${memberId}/stats`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      setStats(data);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const shareUrl = `${window.location.origin}?ref=${stats?.referral_code}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl);
    toast.success("Link copied to clipboard!");
  };

  const shareWhatsApp = () => {
    const text = `Habari! Join the movement for change in Embakasi. Hon. Said Karani is leading the DCP recruitment. Register here: ${shareUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const markOrppDone = async () => {
    try {
      await fetch(`/api/member/${memberId}/orpp`, { method: "POST" });
      toast.success("ORPP status updated!");
      fetchStats();
    } catch (error) {
      toast.error("Failed to update status");
    }
  };

  if (loading) return <div className="p-8 text-center">Loading your dashboard...</div>;
  if (!stats) return <div className="p-8 text-center">Error loading stats.</div>;

  const invitesLeft = 5 - stats.invitees.length;

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100"
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h2 className="text-3xl font-black text-dcp-green uppercase italic">Welcome, {stats.name}</h2>
            <p className="text-gray-500">You are now part of the DCP Embakasi movement.</p>
          </div>
          <div className="bg-dcp-green/10 px-4 py-2 rounded-full text-dcp-green font-bold border border-dcp-green/20">
            Code: {stats.referral_code}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="p-6 bg-gray-50 rounded-xl border border-gray-200">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <Share2 className="w-5 h-5 text-dcp-green" />
                Your Invite Link
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                You have <strong>{invitesLeft}</strong> invites remaining. Share this link with 5 people you trust in Embakasi.
              </p>
              <div className="flex gap-2">
                <input
                  readOnly
                  value={shareUrl}
                  className="flex-1 bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none"
                />
                <button
                  onClick={copyToClipboard}
                  className="p-2 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4">
                <button
                  onClick={shareWhatsApp}
                  className="flex items-center justify-center gap-2 bg-[#25D366] text-white py-2 rounded-lg font-bold text-sm"
                >
                  <MessageCircle className="w-4 h-4" /> WhatsApp
                </button>
                <button
                  onClick={() => window.open(`sms:?body=${encodeURIComponent(`Join DCP Embakasi: ${shareUrl}`)}`)}
                  className="flex items-center justify-center gap-2 bg-dcp-black text-white py-2 rounded-lg font-bold text-sm"
                >
                  <Phone className="w-4 h-4" /> SMS
                </button>
              </div>
            </div>

            <div className="p-6 bg-red-50 rounded-xl border border-red-100">
              <h3 className="text-lg font-bold mb-2 text-dcp-red flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                Make it Official (ORPP)
              </h3>
              <p className="text-xs text-gray-600 mb-4">
                Official registration is done through the ORPP portal. It's often down, but try when you can.
              </p>
              <div className="space-y-2">
                <a
                  href="https://ippms.orpp.or.ke/auth/login"
                  target="_blank"
                  className="flex items-center justify-between w-full bg-white border border-red-200 p-3 rounded-lg text-sm hover:bg-red-100 transition-colors"
                >
                  <span>ORPP Portal</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
                <button
                  onClick={markOrppDone}
                  className="w-full bg-dcp-red text-white py-2 rounded-lg font-bold text-sm shadow-md hover:opacity-90 transition-all"
                >
                  I've Registered on ORPP
                </button>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center p-6 bg-gray-50 rounded-xl border border-gray-200">
            <h3 className="text-lg font-bold mb-4">Your QR Code</h3>
            <QRCodeSVG value={shareUrl} size={200} />
            <p className="text-xs text-gray-500 mt-4 text-center">
              Let people scan this to register directly under you.
            </p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100"
      >
        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
          <Users className="w-6 h-6 text-dcp-green" />
          Your Referrals ({stats.invitees.length}/5)
        </h3>
        {stats.invitees.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            No referrals yet. Start sharing your link!
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {stats.invitees.map((invitee, i) => (
              <div key={i} className="py-4 flex justify-between items-center">
                <div>
                  <p className="font-bold">{invitee.name}</p>
                  <p className="text-xs text-gray-500">
                    Joined {new Date(invitee.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  {invitee.orpp_registered ? (
                    <span className="bg-green-100 text-green-700 text-[10px] px-2 py-1 rounded-full font-bold uppercase">
                      ORPP Registered
                    </span>
                  ) : (
                    <span className="bg-gray-100 text-gray-500 text-[10px] px-2 py-1 rounded-full font-bold uppercase">
                      Pending ORPP
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
}

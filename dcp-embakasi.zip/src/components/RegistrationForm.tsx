import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { motion } from "motion/react";
import { User, Phone, CreditCard, MapPin, CheckCircle } from "lucide-react";

const schema = z.object({
  name: z.string().min(3, "Full name is required"),
  phone: z.string().regex(/^\+254\d{9}$/, "Phone number must be in +254XXXXXXXXX format"),
  national_id: z.string().min(7, "ID number is required"),
  ward: z.string().min(3, "Ward is required"),
  polling_station: z.string().min(3, "Polling station is required"),
  consent: z.boolean().refine((val) => val === true, "Consent is required"),
});

type FormData = z.infer<typeof schema>;

interface Props {
  referrerCode: string;
  onSuccess: (id: string) => void;
}

export default function RegistrationForm({ referrerCode, onSuccess }: Props) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      phone: "+254",
      consent: false,
    }
  });

  const onSubmit = async (data: FormData) => {
    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...data, referrer_code: referrerCode }),
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error);

      toast.success("Registration successful!");
      onSuccess(result.id);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100 max-w-xl mx-auto -mt-10 relative z-20"
    >
      <h2 className="text-2xl font-bold mb-6 text-dcp-green flex items-center gap-2">
        <CheckCircle className="w-6 h-6" />
        Join the Movement
      </h2>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              {...register("name")}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-dcp-green focus:border-transparent outline-none transition-all"
              placeholder="As per ID"
            />
          </div>
          {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              {...register("phone")}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-dcp-green focus:border-transparent outline-none transition-all"
              placeholder="+254700000000"
            />
          </div>
          {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone.message}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">National ID Number</label>
          <div className="relative">
            <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              {...register("national_id")}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-dcp-green focus:border-transparent outline-none transition-all"
              placeholder="12345678"
            />
          </div>
          {errors.national_id && <p className="text-red-500 text-xs mt-1">{errors.national_id.message}</p>}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Ward</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                {...register("ward")}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-dcp-green focus:border-transparent outline-none transition-all"
                placeholder="e.g. Matopeni"
              />
            </div>
            {errors.ward && <p className="text-red-500 text-xs mt-1">{errors.ward.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Polling Station</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                {...register("polling_station")}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-dcp-green focus:border-transparent outline-none transition-all"
                placeholder="e.g. Primary School"
              />
            </div>
            {errors.polling_station && <p className="text-red-500 text-xs mt-1">{errors.polling_station.message}</p>}
          </div>
        </div>

        <div className="flex items-start gap-2 py-2">
          <input
            type="checkbox"
            {...register("consent")}
            className="mt-1 w-4 h-4 text-dcp-green border-gray-300 rounded focus:ring-dcp-green"
          />
          <label className="text-xs text-gray-600">
            I confirm I wish to be a DCP member and authorize Hon. Said Karani's team to contact me regarding party activities.
          </label>
        </div>
        {errors.consent && <p className="text-red-500 text-xs mt-1">{errors.consent.message}</p>}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full dcp-gradient text-white font-bold py-3 rounded-lg shadow-lg hover:opacity-90 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-wider"
        >
          {isSubmitting ? "Registering..." : "Register Now"}
        </button>
      </form>
    </motion.div>
  );
}

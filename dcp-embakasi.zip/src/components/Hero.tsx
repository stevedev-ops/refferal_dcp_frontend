import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

const MESSAGES = [
  "Memes won't change Kenya. Your registration will.",
  "They don't fear your tweets. They fear your vote.",
  "5 million complaints. Zero registrations. Be different.",
  "Your grandchildren will ask what you did. What will you say?",
  "One term. That's all they get. But only if you register.",
  "The cost of unga is high. The cost of silence is higher.",
  "Stop sharing memes. Start sharing invite links.",
];

export default function Hero() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % MESSAGES.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative overflow-hidden bg-dcp-black py-20 px-6 text-center">
      <div className="absolute inset-0 opacity-20">
        <div className="h-full w-full dcp-gradient" />
      </div>
      
      <div className="relative z-10 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4 inline-block rounded-full bg-dcp-green/20 px-4 py-1.5 text-sm font-semibold text-dcp-green ring-1 ring-inset ring-dcp-green/20"
        >
          DCP Embakasi Movement
        </motion.div>
        
        <h1 className="text-4xl font-black tracking-tight text-white sm:text-6xl mb-8 uppercase italic">
          Democratic Change Party
        </h1>

        <div className="h-32 flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.p
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="text-2xl font-bold text-white sm:text-4xl italic"
            >
              "{MESSAGES[index]}"
            </motion.p>
          </AnimatePresence>
        </div>

        <p className="mt-8 text-lg leading-8 text-gray-300 max-w-2xl mx-auto">
          Hon. Said Karani is building a movement of accountability. 
          Register today and invite 5 trusted people to join the change.
        </p>
      </div>
    </section>
  );
}

import { useState, useEffect } from "react";
import { Toaster } from "sonner";
import Hero from "./components/Hero";
import RegistrationForm from "./components/RegistrationForm";
import Dashboard from "./components/Dashboard";

export default function App() {
  const [referrerCode, setReferrerCode] = useState<string>("KARANI");
  const [memberId, setMemberId] = useState<string | null>(() => {
    return localStorage.getItem("dcp_member_id");
  });
  const [referrerName, setReferrerName] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("ref");
    if (code) {
      setReferrerCode(code);
      fetchReferrerName(code);
    }
  }, []);

  const fetchReferrerName = async (code: string) => {
    try {
      const response = await fetch(`/api/referral/${code}`);
      const data = await response.json();
      if (response.ok) {
        setReferrerName(data.name);
      }
    } catch (error) {
      console.error("Failed to fetch referrer name", error);
    }
  };

  const handleRegistrationSuccess = (id: string) => {
    setMemberId(id);
    localStorage.setItem("dcp_member_id", id);
  };

  const handleLogout = () => {
    setMemberId(null);
    localStorage.removeItem("dcp_member_id");
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Toaster position="top-center" richColors />
      
      <Hero />

      <main className="container mx-auto px-4">
        {memberId ? (
          <div className="space-y-6">
            <div className="flex justify-end mt-4">
              <button
                onClick={handleLogout}
                className="text-xs text-gray-500 hover:text-dcp-red underline"
              >
                Not you? Register again
              </button>
            </div>
            <Dashboard memberId={memberId} />
          </div>
        ) : (
          <div className="space-y-12">
            {referrerName && (
              <div className="max-w-xl mx-auto -mt-16 relative z-30 bg-white/90 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-dcp-green/20 text-center">
                <p className="text-sm font-bold text-dcp-green">
                  You were invited by <span className="text-dcp-red">{referrerName}</span>
                </p>
              </div>
            )}
            <RegistrationForm 
              referrerCode={referrerCode} 
              onSuccess={handleRegistrationSuccess} 
            />
          </div>
        )}
      </main>

      <footer className="mt-20 border-t border-gray-200 py-12 bg-white text-center">
        <div className="max-w-4xl mx-auto px-6">
          <p className="text-sm text-gray-500 mb-4">
            &copy; 2026 Democratic Change Party (DCP) Embakasi. 
            Authorized by Hon. Said Karani.
          </p>
          <div className="flex justify-center gap-6">
            <a href="#" className="text-xs text-gray-400 hover:text-dcp-green">Privacy Policy</a>
            <a href="#" className="text-xs text-gray-400 hover:text-dcp-green">Terms of Service</a>
            <a href="#" className="text-xs text-gray-400 hover:text-dcp-green">Contact Us</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import { v4 as uuidv4 } from "uuid";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("dcp_members.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS members (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    national_id TEXT NOT NULL UNIQUE,
    ward TEXT NOT NULL,
    polling_station TEXT NOT NULL,
    referral_code TEXT NOT NULL UNIQUE,
    referrer_id TEXT,
    orpp_registered BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (referrer_id) REFERENCES members(id)
  );
`);

// Seed Hon. Karani if not exists
const seedExists = db.prepare("SELECT id FROM members WHERE referral_code = 'KARANI'").get();
if (!seedExists) {
  db.prepare(`
    INSERT INTO members (id, name, phone, national_id, ward, polling_station, referral_code)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(uuidv4(), "Hon. Said Karani", "0700000000", "00000000", "Embakasi Central", "Seed Station", "KARANI");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Get member by referral code
  app.get("/api/referral/:code", (req, res) => {
    const member = db.prepare("SELECT id, name, ward FROM members WHERE referral_code = ?").get(req.params.code);
    if (!member) return res.status(404).json({ error: "Invalid referral code" });
    res.json(member);
  });

  // Register new member
  app.post("/api/register", (req, res) => {
    const { name, phone, national_id, ward, polling_station, referrer_code } = req.body;

    try {
      const referrer = db.prepare("SELECT id FROM members WHERE referral_code = ?").get(referrer_code) as { id: string } | undefined;
      if (!referrer && referrer_code !== 'KARANI') {
        return res.status(400).json({ error: "Invalid referrer" });
      }

      // Check if referrer has reached limit (5)
      if (referrer) {
        const inviteCount = db.prepare("SELECT COUNT(*) as count FROM members WHERE referrer_id = ?").get(referrer.id) as { count: number };
        if (inviteCount.count >= 5 && referrer_code !== 'KARANI') {
          return res.status(400).json({ error: "This referral link has reached its limit of 5 invites." });
        }
      }

      const id = uuidv4();
      const newReferralCode = Math.random().toString(36).substring(2, 8).toUpperCase();

      db.prepare(`
        INSERT INTO members (id, name, phone, national_id, ward, polling_station, referral_code, referrer_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, name, phone, national_id, ward, polling_station, newReferralCode, referrer?.id || null);

      res.json({ id, referral_code: newReferralCode });
    } catch (error: any) {
      if (error.message.includes("UNIQUE constraint failed")) {
        return res.status(400).json({ error: "Phone number or ID already registered." });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get member stats
  app.get("/api/member/:id/stats", (req, res) => {
    const member = db.prepare("SELECT name, referral_code FROM members WHERE id = ?").get(req.params.id) as any;
    if (!member) return res.status(404).json({ error: "Member not found" });

    const invitees = db.prepare("SELECT name, orpp_registered, created_at FROM members WHERE referrer_id = ?").all(req.params.id);
    res.json({
      name: member.name,
      referral_code: member.referral_code,
      invitees
    });
  });

  // Update ORPP status
  app.post("/api/member/:id/orpp", (req, res) => {
    db.prepare("UPDATE members SET orpp_registered = 1 WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
